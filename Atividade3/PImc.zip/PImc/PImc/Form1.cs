﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void mskxAltura_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(mskxAltura, "");
                altura = Convert.ToDouble(mskxAltura.Text);
                if (altura < 0)
                    throw new Exception("Não pode ser 0");
            }
            catch (Exception ex)
            {
                errorProvider2.SetError(mskxAltura, ex.Message);
                mskxAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            txtImc.Text = "";
            imc = Math.Round(peso / Math.Pow(altura, 2),1);
            txtImc.Text = imc.ToString();
            if (imc <= 16.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (imc <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (imc <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (imc <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade grave");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskxPeso.Clear();
            mskxAltura.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskxPeso_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(mskxPeso, "");
                peso = Convert.ToDouble(mskxPeso.Text);

                if (peso <= 0)
                    throw new Exception("não pode ser zero");

            }
            catch (Exception ex)
            {
                errorProvider1.SetError(mskxPeso, ex.Message);
                mskxPeso.Focus();
            }
        }
    }
}
