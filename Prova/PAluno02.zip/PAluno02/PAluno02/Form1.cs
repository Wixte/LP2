﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[2, 3];
            double mediaParcial = 0;
            double media = 0;
            string auxiliar;
            string separador;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do {i + 1}º, do {j + 1}º professor.", "Entrada de dados:");
                    if(!Double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida");
                        j--;
                    }
                    else if (notas[i,j] < 0 || notas[i,j] > 10)
                    {
                        MessageBox.Show("As notas precisar ser números positivos menores ou iguais a 10.");
                        j--;
                    }
                }
                mediaParcial = (notas[i, 0] + notas[i, 1] + notas[i, 2])/3;
                auxiliar = $"Aluno.{i + 1} -- Nota Professor 1: {notas[i, 0].ToString("N2")}. -- Nota Professor 2: {notas[i, 1].ToString("N2")}. -- Nota Professor 3: {notas[i, 2].ToString("N2")}. -- Média: {mediaParcial.ToString("N2")}";
                lstbxNotas.Items.Add(auxiliar);
                media += notas[i, 0] + notas[i, 1] + notas[i, 2];
            }

            media = media / 6;
            auxiliar = $"Média geral dos alunos: {media.ToString("N2")}";
            separador = "....................";
            lstbxNotas.Items.Add(separador);
            lstbxNotas.Items.Add(auxiliar);

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxNotas.Items.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
