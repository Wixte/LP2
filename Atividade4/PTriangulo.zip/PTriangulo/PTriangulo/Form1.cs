﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC, resultado;

        private void txtValorC_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider3.SetError(txtValorC, "");
                valorC = Convert.ToDouble(txtValorC.Text);
                if (valorC <= 0)
                    throw new Exception("não pode ser menor ou igual a zero");
            }
            catch (Exception ex)
            {
                errorProvider3.SetError(txtValorC, ex.Message);
                txtValorC.Focus();
            }
        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {   
            if (Math.Abs(valorB - valorC) < valorA && valorA < (valorB + valorC) &&
                Math.Abs(valorA - valorC) < valorB && valorB < (valorA + valorC) &&
                Math.Abs(valorA - valorB) < valorC && valorC < (valorA + valorB)) 
            {
                if (valorA == valorB && valorA == valorC)
                {
                    txtResultado.Text = "Triângulo Equilátero";
                }
                else if (valorA != valorB && valorA != valorC && valorB != valorC)
                {
                    txtResultado.Text = "Triângulo Escaleno";
                }
                else
                {
                    txtResultado.Text = "Triângulo Isósceles";
                }

            }
            else
            {
                MessageBox.Show("Os valores informados não formam um triângulo");
            }

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtValorB_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtValorB, "");
                valorB = Convert.ToDouble(txtValorB.Text);
                if (valorB <= 0)
                    throw new Exception("não pode ser menor ou igual a zero");
            }
            catch (Exception ex)
            {
                errorProvider2.SetError(txtValorB, ex.Message);
                txtValorB.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtValorA_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtValorA, "");
                valorA = Convert.ToDouble(txtValorA.Text);
                if (valorA <= 0)
                    throw new Exception("não pode ser menor igual a zero");
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtValorA, ex.Message);
                txtValorA.Focus();
            }
        }
    }
}
