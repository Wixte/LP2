﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] vetor = new string[10];
            int[] auxiliar = new int[10];

            for (int i = 0; i < vetor.Length; i++)
            {
                vetor[i] = Interaction.InputBox($"Digite o {i + 1}º nome completo", "Entrada de dados");
                if (vetor[i] == "")
                {
                    MessageBox.Show("O nome não pode ser vazio.");
                    i--;
                }
            }

            for (int i = 0; i < vetor.Length; i++)
            {
                int temp = 0;
                foreach (char a in vetor[i])
                {
                    if(a == ' ')
                    {
                        continue;
                    }
                    temp++;
                    auxiliar[i] = temp;
                }
                vetor[i] = $"O nome: {vetor[i]} tem {auxiliar[i]} caracteres.";
            }
            lstbxFrase.Text = "";

            foreach (var a  in vetor)
            {
                lstbxFrase.Items.Add(a);
            }
        }
    }
}
