﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExame_Click(object sender, EventArgs e)
        {
            string auxiliar;
            char[,] exame = new char[6, 10];
            char[] resposta = new char[] { 'B', 'A', 'B', 'E', 'D', 'A', 'C', 'A', 'D', 'E' };

            for (int i = 0; i < 6; i++)
            {
                for(int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a resposta da {i + 1}a pergunta.", $"Questão nº {i + 1}, aluno {i + 1}.");
                    if (!Char.TryParse(auxiliar, out exame[i,j]))
                    {
                        MessageBox.Show($"A resposta deve ser 'A', 'B', 'C', 'D' ou 'E'.");
                        j--;
                    }
                    else if (exame[i, j] != 'A' && exame[i, j] != 'B' && exame[i, j] != 'C' && exame[i, j] != 'D' && exame[i, j] != 'E')
                    {
                        MessageBox.Show($"A resposta deve ser 'A', 'B', 'C', 'D' ou 'E'.");
                        j--;
                    }
                    else
                    {
                        if (exame[i,j] == resposta[j])
                        {
                            auxiliar = $"Aluno {i + 1} questão {j + 1}. Resposta do aluno: \'{exame[i,j]}\'.  Alternativa correta: {resposta[j]}. Acertou!!";
                            lstbxFrase.Items.Add(auxiliar);
                        }
                        else
                        {
                            auxiliar = $"Aluno {i + 1} questão {j + 1}. Resposta do aluno: \'{exame[i, j]}\'.  Alternativa correta: {resposta[j]}. Errou!!";
                            lstbxFrase.Items.Add(auxiliar);
                        }
                    }
                }
            }
        }
    }
}
