﻿namespace PMatrizes
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExame = new System.Windows.Forms.Button();
            this.lstbxFrase = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnExame
            // 
            this.btnExame.Location = new System.Drawing.Point(62, 165);
            this.btnExame.Name = "btnExame";
            this.btnExame.Size = new System.Drawing.Size(168, 109);
            this.btnExame.TabIndex = 0;
            this.btnExame.Text = "Iniciar Exame";
            this.btnExame.UseVisualStyleBackColor = true;
            this.btnExame.Click += new System.EventHandler(this.btnExame_Click);
            // 
            // lstbxFrase
            // 
            this.lstbxFrase.FormattingEnabled = true;
            this.lstbxFrase.Location = new System.Drawing.Point(311, 34);
            this.lstbxFrase.Name = "lstbxFrase";
            this.lstbxFrase.Size = new System.Drawing.Size(435, 342);
            this.lstbxFrase.TabIndex = 1;
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstbxFrase);
            this.Controls.Add(this.btnExame);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExame;
        private System.Windows.Forms.ListBox lstbxFrase;
    }
}