﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show($"Número {i+1} inválido.");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (var j in vetor)
            {
                auxiliar += j + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList minhaLista = new ArrayList() {"Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"};
            minhaLista.Remove("Otávio");
            string auxiliar = "";

            foreach(var i in minhaLista)
            {
                auxiliar+= i + "\n";
            }

            MessageBox.Show(auxiliar);

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[20];
            string auxiliar;
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}a nota do {i + 1}o aluno", "Entrada de dados");
                    if (!Double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show($"Nota {i + 1} inválida.");
                        j--;
                    } else if (notas[i, j] > 10 || notas[i, j] < 0)
                    {
                        MessageBox.Show($"Nota {i + 1} inválida.");
                        j--;
                    }
                    else
                    {
                        media[i] += notas[i, j];
                    }
                }
            }

            for (int i = 0;i < 20;i++)
            {
                media[i] = media[i] / 3;
            }

            auxiliar = "";
            for(int i = 0; i < 20; i++)
            {
                auxiliar += "Aluno " + (i + 1) + ": média: " + media[i] + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj1 = new frmExercicio4();
            obj1.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj1 = new frmExercicio5();
            obj1.Show();
        }
    }
}
