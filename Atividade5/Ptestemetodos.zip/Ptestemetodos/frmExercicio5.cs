﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        int numero1, numero2, sorteado;
        Random objAleatorio = new Random();

        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (numero2 <= numero1)
            {
                MessageBox.Show("O número dois não pode ser menor ou igual ao número 1");
                txtNumero2.Focus();
            }
            else
            {
                sorteado = objAleatorio.Next(numero1, numero2);
                MessageBox.Show("O número sorteado é = " + sorteado);
            }

        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToInt16(txtNumero2.Text);
                if (numero2 <= 0)
                    throw new Exception("O número dois não pode ser igual ou menor que zero");
            }
            catch (Exception ex)
            {
                errorProvider2.SetError(txtNumero2, ex.Message);
                txtNumero2.Focus();
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(txtNumero1, "");
                numero1 = Convert.ToInt16(txtNumero1.Text);
                if (numero1 < 0)
                    throw new Exception("O número um não pode ser menor do que zero");
            }
            catch (Exception ex)
            {
                errorProvider1.SetError(txtNumero1, ex.Message);
                txtNumero1.Focus();
            }
        }
    }
}
