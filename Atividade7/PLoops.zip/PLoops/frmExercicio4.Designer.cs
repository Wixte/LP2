﻿namespace PLoops
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lnlNome = new Label();
            lblMatricula = new Label();
            lvlProducao = new Label();
            lblSalario = new Label();
            lvlGratificacao = new Label();
            txtNome = new TextBox();
            txtMatricula = new TextBox();
            txtProducao = new TextBox();
            txtSalario = new TextBox();
            txtGratificacao = new TextBox();
            btnCalcular = new Button();
            SuspendLayout();
            // 
            // lnlNome
            // 
            lnlNome.AutoSize = true;
            lnlNome.Location = new Point(27, 27);
            lnlNome.Name = "lnlNome";
            lnlNome.Size = new Size(40, 15);
            lnlNome.TabIndex = 0;
            lnlNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.Location = new Point(27, 52);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(57, 15);
            lblMatricula.TabIndex = 1;
            lblMatricula.Text = "Matrícula";
            // 
            // lvlProducao
            // 
            lvlProducao.AutoSize = true;
            lvlProducao.Location = new Point(27, 76);
            lvlProducao.Name = "lvlProducao";
            lvlProducao.Size = new Size(58, 15);
            lvlProducao.TabIndex = 2;
            lvlProducao.Text = "Produção";
            // 
            // lblSalario
            // 
            lblSalario.AutoSize = true;
            lblSalario.Location = new Point(27, 100);
            lblSalario.Name = "lblSalario";
            lblSalario.Size = new Size(42, 15);
            lblSalario.TabIndex = 3;
            lblSalario.Text = "Salário";
            // 
            // lvlGratificacao
            // 
            lvlGratificacao.AutoSize = true;
            lvlGratificacao.Location = new Point(27, 124);
            lvlGratificacao.Name = "lvlGratificacao";
            lvlGratificacao.Size = new Size(70, 15);
            lvlGratificacao.TabIndex = 4;
            lvlGratificacao.Text = "Gratificação";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(183, 27);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(235, 23);
            txtNome.TabIndex = 5;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(183, 52);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(235, 23);
            txtMatricula.TabIndex = 6;
            // 
            // txtProducao
            // 
            txtProducao.Location = new Point(183, 76);
            txtProducao.Name = "txtProducao";
            txtProducao.Size = new Size(235, 23);
            txtProducao.TabIndex = 7;
            // 
            // txtSalario
            // 
            txtSalario.Location = new Point(183, 100);
            txtSalario.Name = "txtSalario";
            txtSalario.Size = new Size(235, 23);
            txtSalario.TabIndex = 8;
            // 
            // txtGratificacao
            // 
            txtGratificacao.Location = new Point(183, 124);
            txtGratificacao.Name = "txtGratificacao";
            txtGratificacao.Size = new Size(235, 23);
            txtGratificacao.TabIndex = 9;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(183, 219);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(176, 71);
            btnCalcular.TabIndex = 10;
            btnCalcular.Text = "Calcular salário";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 364);
            Controls.Add(btnCalcular);
            Controls.Add(txtGratificacao);
            Controls.Add(txtSalario);
            Controls.Add(txtProducao);
            Controls.Add(txtMatricula);
            Controls.Add(txtNome);
            Controls.Add(lvlGratificacao);
            Controls.Add(lblSalario);
            Controls.Add(lvlProducao);
            Controls.Add(lblMatricula);
            Controls.Add(lnlNome);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lnlNome;
        private Label lblMatricula;
        private Label lvlProducao;
        private Label lblSalario;
        private Label lvlGratificacao;
        private TextBox txtNome;
        private TextBox txtMatricula;
        private TextBox txtProducao;
        private TextBox txtSalario;
        private TextBox txtGratificacao;
        private Button btnCalcular;
    }
}