﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio4 : Form
    {
        double prod, sal, grat;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int b = 0, c = 0, d = 0;
            double bruto = 0;

            try
            {
                prod = Convert.ToDouble(txtProducao.Text);
                if (prod < 0)
                    throw new Exception("");
            }
            catch
            {
                MessageBox.Show("O valor de produção deve ser um número maior ou igual a zero.");
                txtProducao.Focus();
                return;
            }

            try
            {
                sal = Convert.ToDouble(txtSalario.Text);
                if (sal < 0)
                    throw new Exception("");
            }
            catch
            {
                MessageBox.Show("O valor do salário deve ser um número maior ou igual a zero.");
                txtSalario.Focus();
                return;
            }

            try
            {
                grat = Convert.ToDouble(txtGratificacao.Text);
                if (grat < 0)
                    throw new Exception("");
            }
            catch
            {
                MessageBox.Show("O valor da gratificação deve ser um número maior ou igual a zero.");
                txtGratificacao.Focus();
                return;
            }

            if (prod >= 100)
            {
                b = 1;
            }

            if (prod >= 120)
            {
                c = 1;
            }

            if (prod >= 150)
            {
                d = 1;
            }

            bruto = sal + sal * (0.05 * b + 0.1 * c + 0.1 * d) + grat;

            if (bruto > 7000)
            {
                if (prod < 150 || grat <= 0)
                {
                    bruto = 7000;
                }
            }

            MessageBox.Show("O salário bruto é igual a R$" + bruto);
        }
    }
}
