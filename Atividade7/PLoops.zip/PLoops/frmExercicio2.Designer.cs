﻿namespace PLoops
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNumero1 = new TextBox();
            btnGerar = new Button();
            lblNumero1 = new Label();
            SuspendLayout();
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(137, 37);
            txtNumero1.Margin = new Padding(2);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(233, 23);
            txtNumero1.TabIndex = 0;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // btnGerar
            // 
            btnGerar.Location = new Point(137, 174);
            btnGerar.Margin = new Padding(2);
            btnGerar.Name = "btnGerar";
            btnGerar.Size = new Size(155, 65);
            btnGerar.TabIndex = 1;
            btnGerar.Text = "Crie um número";
            btnGerar.UseVisualStyleBackColor = true;
            btnGerar.Click += btnGerar_Click;
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(51, 45);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(60, 15);
            lblNumero1.TabIndex = 2;
            lblNumero1.Text = "Número 1";
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(717, 299);
            Controls.Add(lblNumero1);
            Controls.Add(btnGerar);
            Controls.Add(txtNumero1);
            Margin = new Padding(2);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero1;
        private Button btnGerar;
        private Label lblNumero1;
    }
}