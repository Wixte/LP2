﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio2 : Form
    {
        int n = 0;
        double controle = 0;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGerar_Click(object sender, EventArgs e)
        {
            try
            {
                n = Convert.ToInt16(txtNumero1.Text);
                if (n <= 0)
                    throw new Exception();
            }
            catch (Exception)
            {
                MessageBox.Show("Número invalido.");
                txtNumero1.Focus();
                return;
            }

            for (double i = 1; i <= n; i++)
            {
                controle += 1 / i;
            }
            MessageBox.Show("O valor de h é: " + controle);
            controle = 0;
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            /*try
            {
                n = Convert.ToInt16(txtNumero1.Text);
                if (n <= 0)
                    throw new Exception();
            }
            catch (Exception)
            {
                MessageBox.Show("Número invalido.");
                txtNumero1.Focus();
            }*/
        }
    }
}
