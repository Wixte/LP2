﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBrancos_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (char c in rchtxtPalavra1.Text)
            {
                if (Char.IsWhiteSpace(c))
                {
                    cont++;
                }
            }
            MessageBox.Show("A frase possui " + cont + " espaços em branco.");
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int i;

            for (i = 0; i < rchtxtPalavra1.Text.Length; i++)
            {
                if (rchtxtPalavra1.Text[i] == 'r' || rchtxtPalavra1.Text[i] == 'R')
                {
                    cont++;
                }
            }
            MessageBox.Show("A frase possui " + cont + " letras 'r'.");
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int i = 0;

            while (i < rchtxtPalavra1.Text.Length - 1)
            {
                if (rchtxtPalavra1.Text[i] == rchtxtPalavra1.Text[i + 1])
                {
                    cont++;
                }
                i++;
            }
            MessageBox.Show("A frase possui " + cont + " pares de letras");
        }
    }
}
