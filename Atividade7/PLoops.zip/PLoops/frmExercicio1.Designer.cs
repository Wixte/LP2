﻿namespace PLoops
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnParLetras = new Button();
            btnLetraR = new Button();
            btnBrancos = new Button();
            rchtxtPalavra1 = new RichTextBox();
            SuspendLayout();
            // 
            // btnParLetras
            // 
            btnParLetras.Location = new Point(550, 416);
            btnParLetras.Name = "btnParLetras";
            btnParLetras.Size = new Size(171, 114);
            btnParLetras.TabIndex = 7;
            btnParLetras.Text = "Contar par de letras";
            btnParLetras.UseVisualStyleBackColor = true;
            btnParLetras.Click += btnParLetras_Click;
            // 
            // btnLetraR
            // 
            btnLetraR.Location = new Point(299, 416);
            btnLetraR.Name = "btnLetraR";
            btnLetraR.Size = new Size(171, 114);
            btnLetraR.TabIndex = 6;
            btnLetraR.Text = "Contar letras R";
            btnLetraR.UseVisualStyleBackColor = true;
            btnLetraR.Click += btnLetraR_Click;
            // 
            // btnBrancos
            // 
            btnBrancos.Location = new Point(52, 416);
            btnBrancos.Name = "btnBrancos";
            btnBrancos.Size = new Size(171, 114);
            btnBrancos.TabIndex = 5;
            btnBrancos.Text = "Contar espaços em branco";
            btnBrancos.UseVisualStyleBackColor = true;
            btnBrancos.Click += btnBrancos_Click;
            // 
            // rchtxtPalavra1
            // 
            rchtxtPalavra1.Location = new Point(52, 26);
            rchtxtPalavra1.MaxLength = 100;
            rchtxtPalavra1.Name = "rchtxtPalavra1";
            rchtxtPalavra1.Size = new Size(669, 297);
            rchtxtPalavra1.TabIndex = 4;
            rchtxtPalavra1.Text = "";
            // 
            // frmExercicio1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1385, 669);
            Controls.Add(btnParLetras);
            Controls.Add(btnLetraR);
            Controls.Add(btnBrancos);
            Controls.Add(rchtxtPalavra1);
            Name = "frmExercicio1";
            Text = "frmExercicio1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnParLetras;
        private Button btnLetraR;
        private Button btnBrancos;
        private RichTextBox rchtxtPalavra1;
    }
}