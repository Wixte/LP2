﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio3 : Form
    {

        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            int palin = 0;

            for (var i = 0; i < txtPalavra1.Text.Length; i++)
            {
                if (txtPalavra1.Text[i] == ' ')
                {
                    continue;
                }
                auxiliar += txtPalavra1.Text.ToUpper()[i];
            }

            char[] controle = new char[auxiliar.Length];

            for (var i = 0; i < auxiliar.Length; i++)
            {
                controle[i] = auxiliar[i];
            }

            Array.Reverse(controle);

            for (var i = 0; i < auxiliar.Length; i++)
            {
                if (controle[i] == auxiliar[i])
                {
                    continue;
                }
                palin = 1;

            }

            if (txtPalavra1.Text == "")
            {
                MessageBox.Show("Digite uma frase para testar se é um palíndromo.");
                return;
            }
            if (palin == 1)
            {
                MessageBox.Show("A frase não é um palíndromo");
            }
            else
            {
                MessageBox.Show("A frase é um palíndromo");
            }

        }
    }
}
